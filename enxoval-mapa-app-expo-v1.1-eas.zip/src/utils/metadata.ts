import { parseBRL, domainFromUrl } from './price';

export interface ProductMeta {
  title?: string;
  image?: string;
  price?: number | null;
  currency?: string | null;
  store?: string | null;
}

export async function fetchHtml(url: string): Promise<string> {
  const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 EnxovalApp' }});
  const text = await res.text();
  return text;
}

function findOg(content: string, prop: string): string | undefined {
  const re = new RegExp(`<meta[^>]+property=["']${prop}["'][^>]+content=["']([^"']+)["']`, 'i');
  const m = re.exec(content);
  return m?.[1];
}

function findMeta(content: string, name: string): string | undefined {
  const re = new RegExp(`<meta[^>]+name=["']${name}["'][^>]+content=["']([^"']+)["']`, 'i');
  const m = re.exec(content);
  return m?.[1];
}

function findJsonLd(content: string): any | null {
  const scripts = content.matchAll(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi);
  for (const s of scripts) {
    try {
      const json = JSON.parse(s[1].trim());
      if (Array.isArray(json)) {
        for (const item of json) {
          const ctx = item['@type'] || item['@graph']?.[0]?.['@type'];
          if (ctx && (ctx.includes('Product') || ctx.includes('Offer'))) return item;
        }
      } else {
        const t = json['@type'] || json['@graph']?.[0]?.['@type'];
        if (t && (t.includes('Product') || t.includes('Offer'))) return json;
      }
    } catch {}
  }
  return null;
}

export function extractProduct(content: string, url: string): ProductMeta {
  const store = domainFromUrl(url);
  // OG first
  let title = findOg(content, 'og:title') || findMeta(content, 'title') || undefined;
  let image = findOg(content, 'og:image') || undefined;
  let priceStr = findMeta(content, 'product:price:amount') || findOg(content, 'product:price:amount') || undefined;
  let currency = findMeta(content, 'product:price:currency') || findOg(content, 'product:price:currency') || undefined;
  let price = priceStr ? parseBRL(priceStr) : null;

  // Try common price patterns if price missing
  if (price == null) {
    const priceMatch = content.match(/(?:R\$\s*)?([0-9]{1,3}(?:\.[0-9]{3})*,[0-9]{2})/);
    if (priceMatch) price = parseBRL(priceMatch[1]);
  }

  // JSON-LD
  const ld = findJsonLd(content);
  if (ld) {
    try {
      const prod = Array.isArray(ld['@graph']) ? ld['@graph'].find((x: any)=>x['@type']?.includes('Product')) : ld;
      const offers = prod?.offers || ld?.offers;
      if (!title) title = prod?.name || prod?.title;
      if (!image) image = Array.isArray(prod?.image) ? prod.image[0] : prod?.image;
      if (offers) {
        const ofr = Array.isArray(offers) ? offers[0] : offers;
        if (ofr?.price && !price) price = parseFloat(ofr.price);
        if (ofr?.priceCurrency && !currency) currency = ofr.priceCurrency;
      }
    } catch {}
  }

  return { title, image, price: price ?? null, currency: currency ?? 'BRL', store };
}