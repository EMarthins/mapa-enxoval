export function parseBRL(input: string): number | null {
  if (!input) return null;
  // Accept "R$ 1.234,56", "1234,56", "1299.90"
  let s = input.replace(/[^0-9,.-]/g, '');
  // If both comma and dot present, assume comma is decimal in pt-BR
  if (s.includes(',') && s.includes('.')) {
    s = s.replace(/\./g, '').replace(',', '.');
  } else if (s.includes(',')) {
    s = s.replace(',', '.');
  }
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

export function fmtBRL(n: number | null | undefined) {
  if (n == null) return '—';
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL'}).format(n);
}

export function domainFromUrl(url?: string | null) {
  if (!url) return null;
  try { return new URL(url).hostname.replace(/^www\./,''); } catch { return null; }
}