import { useEffect, useState } from 'react';
import { getDb } from '../db';

export function useRooms(){
  const [rooms, setRooms] = useState<any[]>([]);
  useEffect(()=>{ (async()=>{
    const db = await getDb();
    const rs = await db.getAllAsync('SELECT * FROM rooms ORDER BY id');
    setRooms(rs);
  })(); },[]);
  return { rooms, reload: async ()=>{ const db=await getDb(); const rs=await db.getAllAsync('SELECT * FROM rooms ORDER BY id'); (setRooms as any)(rs);} };
}

export async function getRoomTotals(roomId: number){
  const db = await getDb();
  const items = await db.getAllAsync('SELECT * FROM items WHERE room_id=?', [roomId]);
  const count = items.length;
  const bought = items.filter((i:any)=>i.status==='Comprado').length;
  const boughtPct = count ? bought/count : 0;
  let planned = (await db.getFirstAsync('SELECT budget_planned as b FROM rooms WHERE id=?',[roomId]))?.b ?? 0;
  const estimated = items.reduce((s:any,i:any)=> s + ((i.price_captured||0) * (i.quantity||1)), 0);
  const paid = items.reduce((s:any,i:any)=> s + ((i.paid_price||0) * (i.quantity||1)), 0);
  return { count, boughtPct, planned, estimated, paid };
}

export async function getGlobalTotals(){
  const db = await getDb();
  const rows = await db.getAllAsync('SELECT id FROM rooms');
  let planned=0, estimated=0, paid=0, count=0, bought=0;
  for(const r of rows){
    const t = await getRoomTotals(r.id);
    planned += t.planned||0; estimated += t.estimated||0; paid += t.paid||0;
    count += t.count; bought += t.count * t.boughtPct;
  }
  return { planned, estimated, paid, boughtPct: count ? bought/count : 0, count };
}