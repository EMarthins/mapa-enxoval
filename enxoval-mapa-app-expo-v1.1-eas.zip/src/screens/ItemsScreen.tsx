import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, FlatList } from 'react-native';
import { useThemeColors } from '../theme';
import { getDb } from '../db';
import ItemCard from '../components/ItemCard';
import { useNavigation } from '@react-navigation/native';

export default function ItemsScreen(){
  const { colors } = useThemeColors();
  const nav = useNavigation<any>();
  const [items, setItems] = useState<any[]>([]);
  const [q, setQ] = useState('');
  const [status, setStatus] = useState<string>(''); // TODO: add selectors

  async function load(){
    const db = await getDb();
    const it = await db.getAllAsync('SELECT * FROM items ORDER BY updated_at DESC');
    setItems(it);
  }
  useEffect(()=>{ load(); },[]);

  const filtered = items.filter(i=>(i.title||'').toLowerCase().includes(q.toLowerCase()));

  return (
    <View style={{ flex:1, backgroundColor: colors.background, padding:12 }}>
      <Text style={{ fontSize:22, fontWeight:'700', marginBottom:8, color: colors.text }}>Itens</Text>
      <TextInput placeholder="Buscar..." value={q} onChangeText={setQ}
        style={{ borderWidth:1, borderColor: colors.border, borderRadius:8, padding:10, marginBottom:8 }} />
      <FlatList data={filtered} keyExtractor={(i)=>String(i.id)} contentContainerStyle={{ gap:8 }}
        renderItem={({item})=> <ItemCard item={item} onPress={()=>nav.navigate('ItemDetail',{ itemId: item.id })} /> } />
    </View>
  );
}