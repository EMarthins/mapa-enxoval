import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, Alert } from 'react-native';
import { useThemeColors } from '../theme';
import { getDb } from '../db';
import * as Linking from 'expo-linking';
import { fmtBRL, parseBRL } from '../utils/price';
import { DateTimeFormatOptions } from 'intl';

export default function ItemDetailScreen({ route, navigation }: any){
  const { itemId } = route.params;
  const { colors } = useThemeColors();
  const [item, setItem] = useState<any>(null);

  async function load(){ const db = await getDb(); const i = await db.getFirstAsync('SELECT * FROM items WHERE id=?',[itemId]); setItem(i); }
  useEffect(()=>{ load(); },[]);

  async function update(field: string, value: any){
    const db = await getDb();
    await db.runAsync(`UPDATE items SET ${field}=?, updated_at=? WHERE id=?`, [value, new Date().toISOString(), itemId]);
    await load();
  }

  async function markBought(){
    if (!item?.paid_price) Alert.alert('Atenção','Defina o Preço pago antes.');
    else {
      await update('status','Comprado');
      Alert.alert('Anotado','Item marcado como comprado.');
    }
  }

  if (!item) return null;
  return (
    <ScrollView style={{ flex:1, backgroundColor: colors.background }} contentContainerStyle={{ padding:12, gap:8 }}>
      <Text style={{ fontWeight:'700', fontSize:20, color: colors.text }}>{item.title}</Text>
      <Text style={{ color: colors.muted }}>{item.store_domain || '—'} • Status: {item.status}</Text>

      <Text style={{ marginTop:8 }}>Preço atual: {fmtBRL(item.price_captured)}</Text>
      <TextInput placeholder="Preço alvo (R$)" defaultValue={item.target_price ? String(item.target_price) : ''} keyboardType="decimal-pad"
        onEndEditing={(e)=>update('target_price', parseBRL(e.nativeEvent.text))}
        style={{ borderWidth:1, borderColor: colors.border, borderRadius:8, padding:10 }} />
      <TextInput placeholder="Preço pago (R$)" defaultValue={item.paid_price ? String(item.paid_price) : ''} keyboardType="decimal-pad"
        onEndEditing={(e)=>update('paid_price', parseBRL(e.nativeEvent.text))}
        style={{ borderWidth:1, borderColor: colors.border, borderRadius:8, padding:10 }} />

      <TextInput placeholder="Quantidade" defaultValue={String(item.quantity||1)} keyboardType="number-pad"
        onEndEditing={(e)=>update('quantity', Number(e.nativeEvent.text)||1)}
        style={{ borderWidth:1, borderColor: colors.border, borderRadius:8, padding:10 }} />
      <TextInput placeholder="Variações (tensão, cor, tamanho)"
        defaultValue={[item.voltage,item.color,item.size].filter(Boolean).join(' / ')}
        onEndEditing={(e)=>{
          const parts = e.nativeEvent.text.split('/').map(s=>s.trim());
          update('voltage', parts[0]||null);
          update('color', parts[1]||null);
          update('size', parts[2]||null);
        }}
        style={{ borderWidth:1, borderColor: colors.border, borderRadius:8, padding:10 }} />

      <TextInput placeholder="Etiquetas (vírgulas)"
        defaultValue={item.tags||''}
        onEndEditing={(e)=>update('tags', e.nativeEvent.text)}
        style={{ borderWidth:1, borderColor: colors.border, borderRadius:8, padding:10 }} />

      <TextInput placeholder="Notas"
        defaultValue={item.notes||''} multiline numberOfLines={4}
        onEndEditing={(e)=>update('notes', e.nativeEvent.text)}
        style={{ borderWidth:1, borderColor: colors.border, borderRadius:8, padding:10, minHeight:100 }} />

      <View style={{ flexDirection:'row', gap:8, marginTop:8 }}>
        <Pressable onPress={markBought} style={{ backgroundColor: colors.success, padding:12, borderRadius:10 }}>
          <Text style={{ color:'#fff', fontWeight:'700' }}>Marcar como comprado</Text>
        </Pressable>
        {item.link_url ? (
          <Pressable onPress={()=>Linking.openURL(item.link_url)} style={{ backgroundColor: colors.card, padding:12, borderRadius:10, borderWidth:1, borderColor: colors.border }}>
            <Text>Abrir link</Text>
          </Pressable>
        ) : null}
      </View>
    </ScrollView>
  );
}