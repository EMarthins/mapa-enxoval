import React, { useState } from 'react';
import { View, Text, Pressable, Alert } from 'react-native';
import { useThemeColors } from '../theme';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import * as Print from 'expo-print';
import { getDb } from '../db';
import { fmtBRL } from '../utils/price';

function toCsv(rows: any[]) {
  const headers = ['Comodo','Item','Loja','Link','PrecoAtual','PrecoAlvo','PrecoPago','Status','Quantidade'];
  const lines = [headers.join(',')];
  for(const r of rows){
    const row = [r.room, r.title, r.store_domain||'', r.link_url||'', r.price_captured??'', r.target_price??'', r.paid_price??'', r.status, r.quantity];
    lines.push(row.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(','));
  }
  return lines.join('\n');
}

export default function ExportScreen(){
  const { colors } = useThemeColors();
  const [busy, setBusy] = useState(false);

  async function exportCsv(){
    setBusy(true);
    const db = await getDb();
    const rows = await db.getAllAsync(`
      SELECT rooms.name as room, items.* 
      FROM items JOIN rooms ON rooms.id = items.room_id ORDER BY rooms.id, items.title
    `);
    const csv = toCsv(rows);
    const path = FileSystem.documentDirectory + 'enxoval_export.csv';
    await FileSystem.writeAsStringAsync(path, csv, { encoding: FileSystem.EncodingType.UTF8 });
    setBusy(false);
    if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(path);
    else Alert.alert('Exportado', 'Arquivo salvo em: ' + path);
  }

  async function exportPdf(){
    setBusy(true);
    const db = await getDb();
    const rows = await db.getAllAsync(`
      SELECT rooms.name as room, items.* 
      FROM items JOIN rooms ON rooms.id = items.room_id ORDER BY rooms.id, items.title
    `);
    const rowsHtml = rows.map(r=> `<tr>
      <td>${r.room}</td><td>${r.title}</td><td>${r.store_domain||''}</td>
      <td>${r.link_url||''}</td><td>${fmtBRL(r.price_captured)}</td><td>${fmtBRL(r.target_price)}</td>
      <td>${fmtBRL(r.paid_price)}</td><td>${r.status}</td><td>${r.quantity}</td>
    </tr>`).join('');
    const html = \`<html><meta charset="utf-8"><body>
      <h2>Lista de Enxoval</h2>
      <table border="1" cellspacing="0" cellpadding="4">
      <thead><tr><th>Cômodo</th><th>Item</th><th>Loja</th><th>Link</th><th>Preço atual</th><th>Preço-alvo</th><th>Preço pago</th><th>Status</th><th>Qtd</th></tr></thead>
      <tbody>\${rowsHtml}</tbody></table></body></html>\`;
    const { uri } = await Print.printToFileAsync({ html });
    setBusy(false);
    if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(uri);
    else Alert.alert('PDF gerado', 'Arquivo: ' + uri);
  }

  return (
    <View style={{ flex:1, backgroundColor: colors.background, padding:12, gap:12 }}>
      <Text style={{ fontSize:22, fontWeight:'700', color: colors.text }}>Exportar & Compartilhar</Text>
      <Pressable onPress={exportCsv} disabled={busy} style={{ backgroundColor: colors.card, padding:14, borderRadius:12, borderWidth:1, borderColor: colors.border }}>
        <Text>Exportar CSV</Text>
      </Pressable>
      <Pressable onPress={exportPdf} disabled={busy} style={{ backgroundColor: colors.card, padding:14, borderRadius:12, borderWidth:1, borderColor: colors.border }}>
        <Text>Exportar PDF</Text>
      </Pressable>
    </View>
  );
}