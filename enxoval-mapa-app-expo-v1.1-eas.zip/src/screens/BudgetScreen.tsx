import React, { useEffect, useState } from 'react';
import { View, Text, FlatList } from 'react-native';
import { useThemeColors } from '../theme';
import { getDb } from '../db';
import { getRoomTotals } from '../hooks/useDatabase';
import { fmtBRL } from '../utils/price';

export default function BudgetScreen(){
  const { colors } = useThemeColors();
  const [rows, setRows] = useState<any[]>([]);
  const [summary, setSummary] = useState<any>({planned:0,estimated:0,paid:0});

  async function load(){
    const db = await getDb();
    const rooms = await db.getAllAsync('SELECT * FROM rooms ORDER BY id');
    const data:any[] = [];
    let planned=0,estimated=0,paid=0;
    for(const r of rooms){
      const t = await getRoomTotals(r.id);
      planned += t.planned||0; estimated += t.estimated||0; paid += t.paid||0;
      data.push({ room:r, ...t });
    }
    setRows(data);
    setSummary({ planned, estimated, paid });
  }
  useEffect(()=>{ load(); },[]);

  return (
    <View style={{ flex:1, backgroundColor: colors.background, padding:12 }}>
      <Text style={{ fontSize:22, fontWeight:'700', color: colors.text }}>Orçamento</Text>
      <Text style={{ marginVertical:6, color: colors.muted }}>Planejado: {fmtBRL(summary.planned)} • Estimado: {fmtBRL(summary.estimated)} • Pago: {fmtBRL(summary.paid)}</Text>
      <FlatList data={rows} keyExtractor={(r)=>String(r.room.id)} contentContainerStyle={{ gap:8 }}
        renderItem={({item})=> (
          <View style={{ padding:12, borderRadius:12, backgroundColor: colors.card, borderWidth:1, borderColor: colors.border }}>
            <Text style={{ fontWeight:'700', marginBottom:4 }}>{item.room.icon} {item.room.name}</Text>
            <Text>Planejado: {fmtBRL(item.planned)} • Estimado: {fmtBRL(item.estimated)} • Pago: {fmtBRL(item.paid)}</Text>
          </View>
        )}
      />
    </View>
  );
}