import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, Alert, TextInput, Button, Modal, Pressable, ScrollView } from 'react-native';
import { useThemeColors } from '../theme';
import { getDb } from '../db';
import ItemCard from '../components/ItemCard';
import { extractProduct, fetchHtml } from '../utils/metadata';
import { parseBRL, domainFromUrl } from '../utils/price';
import * as Linking from 'expo-linking';

export default function RoomScreen({ route, navigation }: any){
  const { roomId } = route.params;
  const { colors } = useThemeColors();
  const [room, setRoom] = useState<any>(null);
  const [items, setItems] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [url, setUrl] = useState('');
  const [manual, setManual] = useState({ title:'', price:'', store:'', image:'' });

  async function load(){
    const db = await getDb();
    const r = await db.getFirstAsync('SELECT * FROM rooms WHERE id=?',[roomId]);
    setRoom(r);
    const it = await db.getAllAsync('SELECT * FROM items WHERE room_id=? ORDER BY created_at DESC',[roomId]);
    setItems(it);
  }
  useEffect(()=>{ load(); },[]);

  async function addByUrl(u: string){
    try {
      const html = await fetchHtml(u);
      const meta = extractProduct(html, u);
      const db = await getDb();
      const now = new Date().toISOString();
      await db.runAsync(`INSERT INTO items (room_id,title,link_url,image_url,store_domain,price_captured,price_currency,status,priority,quantity,created_at,updated_at) 
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`, [
        roomId,
        meta.title || 'Item',
        u,
        meta.image || null,
        meta.store || domainFromUrl(u),
        meta.price ?? null,
        meta.currency || 'BRL',
        'Pendente',
        'Média',
        1,
        now, now
      ]);
      setShowAdd(false); setUrl(''); await load();
    } catch (e:any) {
      Alert.alert('Falha ao capturar', 'Não foi possível ler os metadados. Preencha manualmente.');
    }
  }

  async function addManual(){
    const db = await getDb();
    const now = new Date().toISOString();
    await db.runAsync(`INSERT INTO items (room_id,title,link_url,image_url,store_domain,price_captured,price_currency,status,priority,quantity,created_at,updated_at) 
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`, [
      roomId,
      manual.title || 'Item',
      null,
      manual.image || null,
      manual.store || null,
      parseBRL(manual.price||'') ?? null,
      'BRL',
      'Pendente',
      'Média',
      1,
      now, now
    ]);
    setManual({ title:'', price:'', store:'', image:'' });
    setShowAdd(false);
    await load();
  }

  return (
    <View style={{ flex:1, backgroundColor: colors.background, padding:12 }}>
      <Text style={{ fontSize:20, fontWeight:'700', color: colors.text }}>{room?.icon} {room?.name}</Text>
      <View style={{ flexDirection:'row', gap:8, marginVertical:12 }}>
        <Pressable onPress={()=>setShowAdd(true)} style={{ backgroundColor: colors.primary, padding:12, borderRadius:12 }} accessibilityRole="button" accessibilityLabel="Adicionar item por link">
          <Text style={{ color:'#fff', fontWeight:'600' }}>Adicionar item por link</Text>
        </Pressable>
        <Pressable onPress={()=>{ setShowAdd(true); }} style={{ backgroundColor: colors.card, padding:12, borderRadius:12, borderWidth:1, borderColor: colors.border }} accessibilityRole="button" accessibilityLabel="Adicionar item manual">
          <Text>Adicionar item manual</Text>
        </Pressable>
      </View>
      <FlatList
        data={items}
        keyExtractor={(i)=>String(i.id)}
        contentContainerStyle={{ gap:8 }}
        renderItem={({item})=> <ItemCard item={item} onPress={()=>navigation.navigate('ItemDetail',{ itemId: item.id })} />}
      />

      <Modal visible={showAdd} animationType="slide" onRequestClose={()=>setShowAdd(false)}>
        <ScrollView contentContainerStyle={{ padding:16, gap:12 }}>
          <Text style={{ fontSize:18, fontWeight:'700' }}>Adicionar por link</Text>
          <TextInput placeholder="Cole a URL do produto" autoCapitalize="none" keyboardType="url"
            value={url} onChangeText={setUrl} style={{ borderWidth:1, borderColor:'#ccc', borderRadius:8, padding:10 }} />
          <Pressable onPress={()=> addByUrl(url)} style={{ backgroundColor:'#0ea5e9', padding:12, borderRadius:10 }}>
            <Text style={{ color:'#fff', textAlign:'center', fontWeight:'600' }}>Capturar</Text>
          </Pressable>

          <Text style={{ fontSize:18, fontWeight:'700', marginTop:16 }}>Adicionar manual</Text>
          <TextInput placeholder="Nome do item" value={manual.title} onChangeText={(t)=>setManual(s=>({...s,title:t}))} style={{ borderWidth:1, borderColor:'#ccc', borderRadius:8, padding:10 }} />
          <TextInput placeholder="Preço (R$)" value={manual.price} onChangeText={(t)=>setManual(s=>({...s,price:t}))} keyboardType="decimal-pad" style={{ borderWidth:1, borderColor:'#ccc', borderRadius:8, padding:10 }} />
          <TextInput placeholder="Loja" value={manual.store} onChangeText={(t)=>setManual(s=>({...s,store:t}))} style={{ borderWidth:1, borderColor:'#ccc', borderRadius:8, padding:10 }} />
          <TextInput placeholder="URL da imagem (opcional)" value={manual.image} onChangeText={(t)=>setManual(s=>({...s,image:t}))} style={{ borderWidth:1, borderColor:'#ccc', borderRadius:8, padding:10 }} />
          <Pressable onPress={addManual} style={{ backgroundColor:'#10b981', padding:12, borderRadius:10 }}>
            <Text style={{ color:'#fff', textAlign:'center', fontWeight:'600' }}>Salvar manual</Text>
          </Pressable>

          <Pressable onPress={()=>setShowAdd(false)} style={{ marginTop:20, padding:12 }}>
            <Text style={{ textAlign:'center' }}>Fechar</Text>
          </Pressable>
        </ScrollView>
      </Modal>
    </View>
  );
}