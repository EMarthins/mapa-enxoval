import React, { useEffect, useState } from 'react';
import { View, Text, TextInput } from 'react-native';
import { useThemeColors } from '../theme';
import { getDb } from '../db';

export default function SettingsScreen(){
  const { colors } = useThemeColors();
  const [rows, setRows] = useState<any[]>([]);

  async function load(){
    const db = await getDb();
    const rooms = await db.getAllAsync('SELECT * FROM rooms ORDER BY id');
    setRows(rooms);
  }
  useEffect(()=>{ load(); },[]);

  async function setBudget(roomId:number, v:string){
    const db = await getDb();
    const n = Number(v.replace(/[^0-9,.-]/g,'').replace(',','.'));
    await db.runAsync('UPDATE rooms SET budget_planned=? WHERE id=?',[Number.isFinite(n)?n:null, roomId]);
  }

  return (
    <View style={{ flex:1, backgroundColor: colors.background, padding:12, gap:8 }}>
      <Text style={{ fontSize:22, fontWeight:'700', color: colors.text }}>Configurações</Text>
      <Text style={{ color: colors.muted }}>Defina metas de orçamento por cômodo</Text>
      {rows.map(r=> (
        <View key={r.id} style={{ backgroundColor: colors.card, padding:12, borderRadius:12, borderWidth:1, borderColor: colors.border }}>
          <Text style={{ fontWeight:'600', marginBottom:6 }}>{r.icon} {r.name}</Text>
          <TextInput placeholder="Orçamento (R$)" defaultValue={r.budget_planned?String(r.budget_planned):''}
            onEndEditing={(e)=>setBudget(r.id, e.nativeEvent.text)}
            keyboardType="decimal-pad"
            style={{ borderWidth:1, borderColor: colors.border, borderRadius:8, padding:10, backgroundColor:'#fff' }} />
        </View>
      ))}
    </View>
  );
}