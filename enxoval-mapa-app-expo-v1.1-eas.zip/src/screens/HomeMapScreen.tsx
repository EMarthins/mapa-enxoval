import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, RefreshControl } from 'react-native';
import RoomCard from '../components/RoomCard';
import { useRooms } from '../hooks/useDatabase';
import { getRoomTotals } from '../hooks/useDatabase';
import { useThemeColors } from '../theme';
import { useIsFocused, useNavigation } from '@react-navigation/native';

export default function HomeMapScreen(){
  const { colors } = useThemeColors();
  const { rooms } = useRooms();
  const isFocused = useIsFocused();
  const nav = useNavigation<any>();
  const [totals, setTotals] = useState<Record<number, any>>({});
  const [loading, setLoading] = useState(false);

  async function refresh(){
    setLoading(true);
    const map: Record<number, any> = {};
    for(const r of rooms){ map[r.id] = await getRoomTotals(r.id); }
    setTotals(map);
    setLoading(false);
  }
  useEffect(()=>{ if(isFocused) refresh(); },[isFocused, rooms.length]);

  return (
    <View style={{ flex:1, backgroundColor: colors.background, padding:12 }}>
      <FlatList
        data={rooms}
        numColumns={2}
        keyExtractor={(r)=>String(r.id)}
        columnWrapperStyle={{ gap:12 }}
        contentContainerStyle={{ gap:12 }}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={refresh} />}
        renderItem={({item})=> (
          <View style={{ flex:1 }}>
            <RoomCard room={item} totals={totals[item.id]||{count:0,boughtPct:0,planned:0,estimated:0,paid:0}} onPress={()=>nav.navigate('Room', { roomId: item.id })} />
          </View>
        )}
        ListHeaderComponent={<Text style={{ fontSize:22, fontWeight:'700', marginBottom:8, color: colors.text }}>Mapa da Casa</Text>}
      />
    </View>
  );
}