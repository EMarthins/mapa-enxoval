import * as SQLite from 'expo-sqlite';

let db: SQLite.SQLiteDatabase | null = null;

export async function getDb() {
  if (!db) {
    db = await SQLite.openDatabaseAsync('enxoval.db');
    await db.execAsync(`
      PRAGMA journal_mode = WAL;
      CREATE TABLE IF NOT EXISTS rooms (
        id INTEGER PRIMARY KEY NOT NULL,
        name TEXT NOT NULL,
        icon TEXT NOT NULL,
        budget_planned REAL
      );
      CREATE TABLE IF NOT EXISTS items (
        id INTEGER PRIMARY KEY NOT NULL,
        room_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        link_url TEXT,
        image_url TEXT,
        store_domain TEXT,
        price_captured REAL,
        price_currency TEXT,
        status TEXT NOT NULL,
        priority TEXT NOT NULL,
        quantity INTEGER NOT NULL DEFAULT 1,
        target_price REAL,
        paid_price REAL,
        paid_date TEXT,
        notes TEXT,
        tags TEXT,
        voltage TEXT,
        color TEXT,
        size TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY(room_id) REFERENCES rooms(id)
      );
    `);
    // seed default rooms if empty
    const row = await db.getFirstAsync('SELECT COUNT(*) as c FROM rooms');
    if ((row?.c ?? 0) === 0) {
      const defaults = [
        ['Sala','🛋️'],['Cozinha','🍳'],['Quarto','🛏️'],['Banheiro','🚿'],
        ['Lavanderia','🧺'],['Área Externa','🌿'],['Escritório','💻'],['Outros','📦']
      ];
      const now = Date.now();
      for (const [name, icon] of defaults) {
        await db.runAsync('INSERT INTO rooms (name, icon, budget_planned) VALUES (?,?,?)', [name, icon, null]);
      }
    }
  }
  return db;
}