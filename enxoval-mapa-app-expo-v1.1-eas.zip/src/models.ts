export type RoomKey = 
  | 'Sala' | 'Cozinha' | 'Quarto' | 'Banheiro' | 'Lavanderia' | 'Área Externa' | 'Escritório' | 'Outros';

export type ItemStatus = 'Pendente' | 'Em observação' | 'Comprado' | 'Desejado';
export type Priority = 'Baixa' | 'Média' | 'Alta';

export interface Room {
  id: number;
  name: RoomKey;
  icon: string;
  budget_planned: number | null;
}

export interface Item {
  id: number;
  room_id: number;
  title: string;
  link_url: string | null;
  image_url: string | null;
  store_domain: string | null;
  price_captured: number | null;
  price_currency: string | null;
  status: ItemStatus;
  priority: Priority;
  quantity: number;
  target_price: number | null;
  paid_price: number | null;
  paid_date: string | null;
  notes: string | null;
  tags: string | null;
  voltage: string | null;
  color: string | null;
  size: string | null;
  created_at: string;
  updated_at: string;
}