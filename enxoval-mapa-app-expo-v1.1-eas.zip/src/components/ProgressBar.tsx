import React from 'react';
import { View } from 'react-native';

export default function ProgressBar({ value, color, bg='#e5e7eb', height=8, radius=999 }:{value:number;color:string;bg?:string;height?:number;radius?:number}){
  const v = Math.max(0, Math.min(1, value || 0));
  return (
    <View style={{ width: '100%', backgroundColor: bg, height, borderRadius: radius }}>
      <View style={{ width: `${v*100}%`, backgroundColor: color, height, borderRadius: radius }} />
    </View>
  );
}