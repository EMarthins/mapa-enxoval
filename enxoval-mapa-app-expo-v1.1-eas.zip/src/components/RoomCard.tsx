import React from 'react';
import { View, Text, Pressable } from 'react-native';
import ProgressBar from './ProgressBar';
import { fmtBRL } from '../utils/price';
import { useThemeColors } from '../theme';

export default function RoomCard({room, totals, onPress}:{room:any; totals:{count:number; boughtPct:number; planned:number; estimated:number; paid:number}; onPress:()=>void}){
  const { colors } = useThemeColors();
  return (
    <Pressable onPress={onPress} accessibilityRole="button" accessibilityLabel={`Abrir ${room.name}`}>
      <View style={{ backgroundColor: colors.card, padding: 12, borderRadius: 16, borderWidth:1, borderColor: colors.border, gap: 8 }}>
        <Text style={{ fontSize: 22 }}>{room.icon} {room.name}</Text>
        <Text style={{ color: colors.muted, fontSize: 12 }}>{totals.count} itens</Text>
        <ProgressBar value={totals.boughtPct} color={colors.success} />
        <View style={{ flexDirection: 'row', justifyContent:'space-between' }}>
          <Text style={{ fontSize: 12, color: colors.muted }}>Planejado: {fmtBRL(totals.planned)}</Text>
          <Text style={{ fontSize: 12, color: colors.muted }}>Pago: {fmtBRL(totals.paid)}</Text>
        </View>
      </View>
    </Pressable>
  );
}