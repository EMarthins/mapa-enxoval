import React from 'react';
import { View, Text, Image, Pressable } from 'react-native';
import { fmtBRL } from '../utils/price';
import { useThemeColors } from '../theme';

export default function ItemCard({ item, onPress }:{ item:any; onPress:()=>void }){
  const { colors } = useThemeColors();
  return (
    <Pressable onPress={onPress} accessibilityRole="button">
      <View style={{ flexDirection:'row', gap:12, backgroundColor: colors.card, padding:10, borderRadius:12, borderWidth:1, borderColor: colors.border }}>
        {item.image_url ? <Image source={{ uri: item.image_url }} style={{ width:56, height:56, borderRadius:8 }} /> : <View style={{ width:56, height:56, borderRadius:8, backgroundColor: colors.chip }} />}
        <View style={{ flex:1 }}>
          <Text numberOfLines={2} style={{ fontWeight:'600', color: colors.text }}>{item.title}</Text>
          <Text style={{ color: colors.muted, fontSize:12 }}>{item.store_domain || '—'} • {item.status}</Text>
          <Text style={{ marginTop:4 }}>{fmtBRL((item.price_captured||0)*item.quantity)}</Text>
        </View>
        <View style={{ alignItems:'flex-end' }}>
          <Text style={{ fontSize: 12, paddingHorizontal:8, paddingVertical:2, backgroundColor: colors.chip, borderRadius:8 }}>{item.priority}</Text>
        </View>
      </View>
    </Pressable>
  );
}