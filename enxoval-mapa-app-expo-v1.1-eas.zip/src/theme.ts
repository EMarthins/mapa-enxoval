import { useColorScheme } from 'react-native';

export function useThemeColors() {
  const scheme = useColorScheme();
  const isDark = scheme === 'dark';
  return {
    isDark,
    colors: {
      background: isDark ? '#0b0f14' : '#ffffff',
      card: isDark ? '#10151b' : '#f7f7f8',
      text: isDark ? '#e6edf3' : '#1b1f24',
      muted: isDark ? '#8892a0' : '#6b7280',
      primary: '#0ea5e9',
      success: '#10b981',
      danger: '#ef4444',
      warning: '#f59e0b',
      border: isDark ? '#1f2937' : '#e5e7eb',
      chip: isDark ? '#111827' : '#eef2f7'
    }
  };
}