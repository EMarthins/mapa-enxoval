import React from 'react';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeMapScreen from './src/screens/HomeMapScreen';
import RoomScreen from './src/screens/RoomScreen';
import ItemsScreen from './src/screens/ItemsScreen';
import BudgetScreen from './src/screens/BudgetScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import ExportScreen from './src/screens/ExportScreen';
import ItemDetailScreen from './src/screens/ItemDetailScreen';
import { useColorScheme, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

function HomeStack(){
  return (
    <Stack.Navigator>
      <Stack.Screen name="HomeMap" component={HomeMapScreen} options={{ title: 'Mapa' }} />
      <Stack.Screen name="Room" component={RoomScreen} options={{ title: 'Cômodo' }} />
      <Stack.Screen name="ItemDetail" component={ItemDetailScreen} options={{ title: 'Item' }} />
    </Stack.Navigator>
  );
}

export default function App(){
  const scheme = useColorScheme();
  return (
    <NavigationContainer theme={scheme === 'dark' ? DarkTheme : DefaultTheme}>
      <Tab.Navigator screenOptions={({route})=>({
        headerShown: false,
        tabBarIcon: ({ color, size }) => {
          const name = route.name === 'Mapa' ? 'home' : route.name === 'Itens' ? 'list' : route.name === 'Orçamento' ? 'cash' : 'settings';
          return <Ionicons name={name as any} size={size} color={color} />;
        }
      })}>
        <Tab.Screen name="Mapa" component={HomeStack} />
        <Tab.Screen name="Itens" component={ItemsScreen} />
        <Tab.Screen name="Orçamento" component={BudgetScreen} />
        <Tab.Screen name="Perfil" component={SettingsScreen} options={{ title: 'Perfil/Config' }} />
        <Tab.Screen name="Exportar" component={ExportScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}